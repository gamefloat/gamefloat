CuBrush is a room-scale experiment with Oculus Rift that lets you walk around
and draw with cubes within a 3D environment. It's designed to work with a single
tracking camera and an Xbox controller, so no motion controllers are required.

It has its own chaperone-style boundary system - Unity doesn't track when the
headset is taken off so boundaries need to be set (carefully) while wearing
the headset or by holding the headset and covering the head sensor.

http://game-float.com/vr/cubrush/

It's only been tested on Oculus, it should run on the Vive too but you may
need Revive to get it working, see:
https://github.com/LibreVR/Revive#standalone-games